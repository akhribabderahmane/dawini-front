import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { CommonModule } from '@angular/common'; // Added CommonModule
import { FormsModule } from '@angular/forms';
import { FilterPipe } from "../../filter.pipe"; // Added FormsModule

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule, // Added CommonModule
    FormsModule,
    FilterPipe
],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  searchQuery: string = ''; // Used for search functionality
  patients: any[] = []; // Holds the list of patients

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    // Load patients when the component is initialized
    this.loadPatients();
  }

  // Method to load patients from the JSON file
  loadPatients(): void {
    this.http.get<any[]>('assets/data1.json').subscribe(
      (data) => {
        this.patients = data;
        console.log('Patient data loaded:', this.patients); // Log data for debugging
      },
      (error) => {
        console.error('Error loading patient data:', error); // Log errors
      }
    );
  }
}
