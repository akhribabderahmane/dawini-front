import { Component, OnInit } from '@angular/core';
import { AboutComponent } from '../../components/about/about.component';
import { HeaderComponent } from '../../components/header/header.component'; // Added HeaderComponent
import { LoginComponent } from '../../components/login/login.component';
import { FooterComponent } from '../../components/footer/footer.component'; // Added FooterComponent
import { DoctorsComponent } from '../../components/doctors/doctors.component';
import { SidebarComponent } from '../../components/sidebar/sidebar.component';
import { CommonModule } from '@angular/common'; // Added CommonModule
import { FormsModule } from '@angular/forms';
import { FilterPipe } from "../../filter.pipe"; // Added FormsModule
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    LoginComponent,
    SidebarComponent,
    FilterPipe ,
    FormsModule,
    CommonModule
],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})


export class HomeComponent implements OnInit {
  searchQuery: string = ''; // Used for search functionality
  patients: any[] = []; // Holds the list of patients

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    // Load patients when the component is initialized
    this.loadPatients();
  }

  // Method to load patients from the JSON file
  loadPatients(): void {
    this.http.get<any[]>('assets/data1.json').subscribe(
      (data) => {
        this.patients = data;
        console.log('Patient data loaded:', this.patients); // Log data for debugging
      },
      (error) => {
        console.error('Error loading patient data:', error); // Log errors
      }
    );
  }
}

